mod debian/imagick.ini
